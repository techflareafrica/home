const toggle=document.querySelector('.nav-toggle');const links=document.querySelector('.nav-links');if(toggle&&links){toggle.addEventListener('click',()=>{const open=links.classList.toggle('open');toggle.setAttribute('aria-expanded',String(open));toggle.textContent=open?'✕':'☰'});links.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{links.classList.remove('open');toggle.setAttribute('aria-expanded','false');toggle.textContent='☰'}))}document.querySelectorAll('[data-year]').forEach(el=>el.textContent=new Date().getFullYear());const form=document.querySelector('#contact-form');if(form){form.addEventListener('submit',e=>{e.preventDefault();const fd=new FormData(form);const subject=encodeURIComponent('Website enquiry from '+fd.get('name'));const body=encodeURIComponent(`Name: ${fd.get('name')}\nEmail: ${fd.get('email')}\nCompany: ${fd.get('company')||'Not provided'}\n\n${fd.get('message')}`);window.location.href=`mailto:hello@techflareafrica.com?subject=${subject}&body=${body}`})}

// Dark mode: honour a saved choice, then the visitor's system preference.
const themeButton=document.querySelector('.theme-toggle');
const savedTheme=localStorage.getItem('techflare-theme');
const preferredTheme=savedTheme||(window.matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light');
function applyTheme(theme){
  document.documentElement.dataset.theme=theme;
  if(themeButton){
    const dark=theme==='dark';
    themeButton.textContent=dark?'☀':'☾';
    themeButton.setAttribute('aria-label',dark?'Switch to light mode':'Switch to dark mode');
    themeButton.setAttribute('title',dark?'Switch to light mode':'Switch to dark mode');
  }
}
applyTheme(preferredTheme);
if(themeButton){themeButton.addEventListener('click',()=>{const next=document.documentElement.dataset.theme==='dark'?'light':'dark';localStorage.setItem('techflare-theme',next);applyTheme(next)})}

// Demo newsletter sign-up. Replace with your email provider endpoint before launch.
document.querySelectorAll('.newsletter-form').forEach(form=>{
  form.addEventListener('submit',event=>{
    event.preventDefault();
    const email=form.querySelector('input[type="email"]');
    const status=form.parentElement.querySelector('.form-status');
    if(!email.checkValidity()){email.reportValidity();return}
    const subscribers=JSON.parse(localStorage.getItem('techflare-newsletter-demo')||'[]');
    if(!subscribers.includes(email.value.toLowerCase())) subscribers.push(email.value.toLowerCase());
    localStorage.setItem('techflare-newsletter-demo',JSON.stringify(subscribers));
    status.textContent='Thanks for subscribing! Connect this form to your email platform before launch.';
    form.reset();
  });
});
